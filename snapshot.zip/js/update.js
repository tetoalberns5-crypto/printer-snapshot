import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
import { getFirestore, doc, getDoc, collection, getDocs } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

const firebaseConfig = {
    apiKey: "AIzaSyCgl2zUTRdjNhfulhmLvc5CCF3D_C60iAE",
    authDomain: "supply-report.firebaseapp.com",
    projectId: "supply-report",
    storageBucket: "supply-report.firebasestorage.app",
    messagingSenderId: "132817519801",
    appId: "1:132817519801:web:fabdc757c9d01241d00768"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

let forceApkUrl = "";

async function checkForForceUpdate() {
    try {
        const updateDoc = await getDoc(doc(db, "app_update", "latest"));
        if (updateDoc.exists()) {
            const updateData = updateDoc.data();
            const enabled = updateData.enabled ?? false;
            const latestVersion = parseFloat(updateData.version || 0);
            const appVer = window.APP_VERSION || 2.4;
            
            if (enabled && latestVersion > appVer) {
                forceApkUrl = updateData.apkUrl || "";
                if (updateData.title) document.getElementById('force-update-title').innerText = updateData.title;
                if (updateData.description) document.getElementById('force-update-desc').innerText = updateData.description;
                document.getElementById('force-update-version').innerText = `الإصدار جديد: v${latestVersion} (إصدارك الحالي: v${appVer})`;
                document.getElementById('force-update-modal').style.display = 'flex';
                return true;
            } else {
                document.getElementById('force-update-modal').style.display = 'none';
                return false;
            }
        }
    } catch (error) {
        console.error("Force update check failed:", error);
    }
    return false;
}

window.checkForForceUpdate = checkForForceUpdate;

window.openForceUpdateUrl = function() {
    const targetUrl = forceApkUrl || (typeof window.updateApkUrl !== 'undefined' ? window.updateApkUrl : "");
    if (!targetUrl) return;

    if (window.AndroidBridge && typeof window.AndroidBridge.downloadAndInstall === "function") {
        const progressDialog = document.getElementById('update-progress-dialog');
        const progressStatus = document.getElementById('update-progress-status');

        if (progressDialog && progressStatus) {
            progressStatus.innerText = "جارٍ تنزيل التحديث...";
            progressDialog.style.display = "flex";

            setTimeout(() => {
                progressStatus.innerText = "جاري تجهيز التثبيت...";
            }, 2000);

            setTimeout(() => {
                progressDialog.style.display = "none";
            }, 5000);
        }

        try {
            window.AndroidBridge.downloadAndInstall(targetUrl);
        } catch (e) {
            console.error("AndroidBridge downloadAndInstall error:", e);
            window.open(targetUrl, '_blank');
            if (progressDialog) progressDialog.style.display = "none";
        }
    } else {
        window.open(targetUrl, '_blank');
    }
};

window.addEventListener('focus', () => { checkForForceUpdate(); });
document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') {
        checkForForceUpdate();
    }
});

async function syncApp() {
    const isForceUpdateActive = await checkForForceUpdate();
    if (isForceUpdateActive) return;

    if (!navigator.onLine) {
        document.getElementById('offline-bar').style.display = 'block';
        return;
    }
    document.getElementById('offline-bar').style.display = 'none';

    try {
        const infoSnap = await getDoc(doc(db, "settings", "app_info"));
        if (infoSnap.exists()) {
            const data = infoSnap.data();
            const appVer = window.APP_VERSION || 2.4;
            
            if (data.version > appVer) {
                if (localStorage.getItem('shown_version') !== String(data.version)) {
                    document.getElementById('update-msg').innerText = `نسخة جديدة متوفرة v${data.version}`;
                    document.getElementById('update-popup').style.display = 'flex';
                    localStorage.setItem('shown_version', data.version);
                    if (window.playSoundSafe) window.playSoundSafe("Save.mp3");
                }
            }

            if (data.announcement && localStorage.getItem('last_admin_msg') !== data.announcement) {
                document.getElementById('admin-msg').innerText = data.announcement;
                document.getElementById('admin-popup').style.display = 'flex';
                localStorage.setItem('last_admin_msg', data.announcement);
                if (window.playSoundSafe) window.playSoundSafe("Save.mp3");
            }
        }

        const azkarSnap = await getDocs(collection(db, "azkar"));
        const newList = azkarSnap.docs.map(d => d.data().text);
        if (newList.length > 0) {
            localStorage.setItem('local_azkar', JSON.stringify(newList));
        }

    } catch (error) {
        console.error("Sync failed:", error);
    }
}

window.syncApp = syncApp;

window.handleManualUpdate = async function() {
    if (window.toggleMenu) window.toggleMenu();
    if (window.showNotification) window.showNotification("جاري البحث عن تحديث...", "warning");
    
    if (!navigator.onLine) {
        if (window.showNotification) window.showNotification("لا يوجد اتصال بالإنترنت", "error");
        return;
    }

    try {
        const isForceUpdate = await checkForForceUpdate();
        if (isForceUpdate) return;

        const infoSnap = await getDoc(doc(db, "settings", "app_info"));
        if (infoSnap.exists()) {
            const data = infoSnap.data();
            const appVer = window.APP_VERSION || 2.4;
            if (data.version > appVer) {
                document.getElementById('update-msg').innerText = `نسخة جديدة متوفرة v${data.version}`;
                document.getElementById('update-popup').style.display = 'flex';
            } else {
                if (window.showNotification) window.showNotification("تطبيقك محدث ✅", "success");
            }
        }
    } catch (e) {
        if (window.showNotification) window.showNotification("حدث خطأ أثناء الفحص", "error");
    }
};

window.downloadUpdate = function() {
    if (window.openForceUpdateUrl) window.openForceUpdateUrl();
};

syncApp();

window.addEventListener('online', syncApp);
window.addEventListener('offline', () => {
    document.getElementById('offline-bar').style.display = 'block';
});
