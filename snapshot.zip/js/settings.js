function toggleSettingsModal() {
    const modal = document.getElementById('settings-modal');
    if (modal) {
        modal.style.display = (modal.style.display === 'none' || modal.style.display === '') ? 'flex' : 'none';
    }
}

function saveSettings() {
    if (window.playSoundSafe) window.playSoundSafe('click.mp3');
    const printerSelect = document.getElementById('printer-mac');
    const settings = JSON.parse(localStorage.getItem('appSettings')) || {};
    if (printerSelect) settings.printerMac = printerSelect.value;
    localStorage.setItem('appSettings', JSON.stringify(settings));
    
    const soundToggle = document.getElementById('sound-toggle');
    if (soundToggle) {
        window.soundEnabled = soundToggle.checked;
        localStorage.setItem('soundEnabled', JSON.stringify(window.soundEnabled));
    }
    if (window.showNotification) window.showNotification('✅ تم حفظ الإعدادات');
    toggleSettingsModal();
}

function updateFontZoom(value) {
    const val = parseInt(value) || 100;
    
    const displayVal = document.getElementById('font-zoom-val-display');
    if(displayVal) displayVal.textContent = val + '%';
    
    const ticks = document.querySelectorAll('.slider-ticks span');
    ticks.forEach(tick => {
        if(parseInt(tick.textContent) === val) {
            tick.classList.add('active-tick');
        } else {
            tick.classList.remove('active-tick');
        }
    });

    localStorage.setItem('fontZoom', val);
    document.documentElement.style.fontSize = val + '%';

    if (window.AndroidBridge && typeof window.AndroidBridge.setTextZoom === "function") {
        try { 
            window.AndroidBridge.setTextZoom(val); 
        } catch(e) { 
            console.error("AndroidBridge setTextZoom Error: ", e); 
        }
    }
}

function initFontZoom() {
    const savedZoom = localStorage.getItem('fontZoom') || '100';
    const slider = document.getElementById('font-zoom-slider');
    if(slider) {
        slider.value = savedZoom;
    }
    updateFontZoom(savedZoom);
}

function toggleInvoiceModal() {
    const modal = document.getElementById('invoice-data-modal');
    if (modal) {
        modal.style.display = (modal.style.display === 'none' || modal.style.display === '') ? 'flex' : 'none';
        if(modal.style.display === 'flex') loadInvoiceSettings();
    }
}

function loadInvoiceSettings() {
    const invSettings = JSON.parse(localStorage.getItem('invoiceSettings')) || {
        title: 'بيان توريد', 
        collectorLabel: 'المحصل',
        collectorName: 'اضف اسمك  ', 
        phone: '010',
        countLabel: 'الناتح',
        categoryLabel: 'الفئة',
        totalLabel: 'العدد',
        note: 'برجاء عدم إتلاف بيان التوريد     ',
        showExpenses: true, showDeficit: true, showDeferred: true, showSupply: true, showNet: true
    };
    if (document.getElementById('inv-title')) document.getElementById('inv-title').value = invSettings.title || '';
    if (document.getElementById('inv-collector-label')) document.getElementById('inv-collector-label').value = invSettings.collectorLabel || '';
    if (document.getElementById('inv-collector')) document.getElementById('inv-collector').value = invSettings.collectorName || '';
    if (document.getElementById('inv-phone')) document.getElementById('inv-phone').value = invSettings.phone || '';
    
    if (document.getElementById('inv-count-label')) document.getElementById('inv-count-label').value = invSettings.countLabel || 'العدد';
    if (document.getElementById('inv-category-label')) document.getElementById('inv-category-label').value = invSettings.categoryLabel || 'الفئة';
    if (document.getElementById('inv-total-label')) document.getElementById('inv-total-label').value = invSettings.totalLabel || 'الناتج';
    
    if (document.getElementById('header-count-label')) document.getElementById('header-count-label').textContent = invSettings.countLabel || 'العدد';
    if (document.getElementById('header-category-label')) document.getElementById('header-category-label').textContent = invSettings.categoryLabel || 'الفئة';
    if (document.getElementById('header-total-label')) document.getElementById('header-total-label').textContent = invSettings.totalLabel || 'الناتج';

    if (document.getElementById('inv-note')) document.getElementById('inv-note').value = invSettings.note || '';
    if (document.getElementById('showExpenses')) document.getElementById('showExpenses').checked = invSettings.showExpenses !== false;
    if (document.getElementById('showDeficit')) document.getElementById('showDeficit').checked = invSettings.showDeficit !== false;
    if (document.getElementById('showDeferred')) document.getElementById('showDeferred').checked = invSettings.showDeferred !== false;
    if (document.getElementById('showSupply')) document.getElementById('showSupply').checked = invSettings.showSupply !== false;
    if (document.getElementById('showNet')) document.getElementById('showNet').checked = invSettings.showNet !== false;
}

function saveInvoiceSettings() {
    if (window.playSoundSafe) window.playSoundSafe('click.mp3');
    const invSettings = {
        title: document.getElementById('inv-title').value.trim(),
        collectorLabel: document.getElementById('inv-collector-label').value.trim(),
        collectorName: document.getElementById('inv-collector').value.trim(),
        phone: document.getElementById('inv-phone').value.trim(),
        countLabel: document.getElementById('inv-count-label').value.trim(),
        categoryLabel: document.getElementById('inv-category-label').value.trim(),
        totalLabel: document.getElementById('inv-total-label').value.trim(),
        note: document.getElementById('inv-note').value.trim(),
        showExpenses: document.getElementById('showExpenses').checked,
        showDeficit: document.getElementById('showDeficit').checked,
        showDeferred: document.getElementById('showDeferred').checked,
        showSupply: document.getElementById('showSupply').checked,
        showNet: document.getElementById('showNet').checked
    };
    localStorage.setItem('invoiceSettings', JSON.stringify(invSettings));
    
    if (document.getElementById('header-count-label')) document.getElementById('header-count-label').textContent = invSettings.countLabel || 'العدد';
    if (document.getElementById('header-category-label')) document.getElementById('header-category-label').textContent = invSettings.categoryLabel || 'الفئة';
    if (document.getElementById('header-total-label')) document.getElementById('header-total-label').textContent = invSettings.totalLabel || 'الناتج';
    
    if (window.showNotification) window.showNotification('✅ تم حفظ بيانات الفاتورة');
    toggleInvoiceModal();
}

function toggleAboutModal() {
    const modal = document.getElementById('about-modal');
    if (modal) {
        modal.style.display = (modal.style.display === 'none' || modal.style.display === '') ? 'flex' : 'none';
    }
}

function toggleMenu() {
    const menu = document.getElementById('sideMenu');
    const overlay = document.getElementById('menuOverlay');
    if (menu && overlay) {
        menu.classList.toggle('open');
        overlay.style.display = menu.classList.contains('open') ? 'block' : 'none';
    }
}

window.toggleSettingsModal = toggleSettingsModal;
window.saveSettings = saveSettings;
window.updateFontZoom = updateFontZoom;
window.initFontZoom = initFontZoom;
window.toggleInvoiceModal = toggleInvoiceModal;
window.loadInvoiceSettings = loadInvoiceSettings;
window.saveInvoiceSettings = saveInvoiceSettings;
window.toggleAboutModal = toggleAboutModal;
window.toggleMenu = toggleMenu;
