function togglePaymentWarningModal() {
    const modal = document.getElementById('payment-warning-modal');
    if (modal) {
        modal.style.display = (modal.style.display === 'none' || modal.style.display === '') ? 'flex' : 'none';
    }
}

function toggleCollectorContactModal() {
    const modal = document.getElementById('collector-contact-modal');
    if (modal) {
        modal.style.display = (modal.style.display === 'none' || modal.style.display === '') ? 'flex' : 'none';
    }
}

function autoSavePaymentWarningData() {
    const warningNote = document.getElementById('warning-note');
    const warningPhone = document.getElementById('warning-phone');
    const data = {
        note: warningNote ? warningNote.value.trim() : '',
        phone: warningPhone ? warningPhone.value.trim() : ''
    };
    localStorage.setItem('paymentWarningData', JSON.stringify(data));
}

function savePaymentWarningModal() {
    autoSavePaymentWarningData();
    if (window.showNotification) window.showNotification('✅ تم حفظ بيانات الإخطار تلقائياً');
    togglePaymentWarningModal();
}

function loadPaymentWarningData() {
    const saved = JSON.parse(localStorage.getItem('paymentWarningData'));
    if (saved) {
        if (document.getElementById('warning-note')) document.getElementById('warning-note').value = saved.note || '';
        if (document.getElementById('warning-phone')) document.getElementById('warning-phone').value = saved.phone || '';
    }
}

function autoSaveCollectorData() {
    const collectorId = document.getElementById('collector-id');
    const vodafonePhone = document.getElementById('vodafone-phone');
    const instapayPhone = document.getElementById('instapay-phone');
    const data = {
        id: collectorId ? collectorId.value.trim() : '',
        vodafone: vodafonePhone ? vodafonePhone.value.trim() : '',
        instapay: instapayPhone ? instapayPhone.value.trim() : ''
    };
    localStorage.setItem('collectorContactData', JSON.stringify(data));
}

function saveCollectorModal() {
    autoSaveCollectorData();
    if (window.showNotification) window.showNotification('✅ تم حفظ بيانات المحصل تلقائياً');
    toggleCollectorContactModal();
}

function loadCollectorContactData() {
    const saved = JSON.parse(localStorage.getItem('collectorContactData'));
    if (saved) {
        if (document.getElementById('collector-id')) document.getElementById('collector-id').value = saved.id || '';
        if (document.getElementById('vodafone-phone')) document.getElementById('vodafone-phone').value = saved.vodafone || '';
        if (document.getElementById('instapay-phone')) document.getElementById('instapay-phone').value = saved.instapay || '';
    }
}

window.togglePaymentWarningModal = togglePaymentWarningModal;
window.toggleCollectorContactModal = toggleCollectorContactModal;
window.autoSavePaymentWarningData = autoSavePaymentWarningData;
window.savePaymentWarningModal = savePaymentWarningModal;
window.loadPaymentWarningData = loadPaymentWarningData;
window.autoSaveCollectorData = autoSaveCollectorData;
window.saveCollectorModal = saveCollectorModal;
window.loadCollectorContactData = loadCollectorContactData;
