function tafqeet(num) {
    if (num === 0) return "صفر";
    const ones = ["", "واحد", "اثنان", "ثلاثة", "أربعة", "خمسة", "ستة", "سبعة", "ثمانية", "تسعة"];
    const teens = ["عشرة", "أحد عشر", "اثنا عشر", "ثلاثة عشر", "أربعة عشر", "خمسة عشر", "ستة عشر", "سبعة عشر", "ثمانية عشر", "تسعة عشر"];
    const tens = ["", "", "عشرون", "ثلاثون", "أربعون", "خمسون", "ستون", "سبعون", "ثمانون", "تسعون"];
    const hundreds = ["", "مائة", "مائتان", "ثلاثمائة", "أربعمائة", "خمسمائة", "ستمائة", "سبعمائة", "ثمانمائة", "تسائة"];
    function process(n) {
        if (n === 0) return "";
        if (n < 10) return ones[n];
        if (n < 20) return teens[n - 10];
        if (n < 100) return ones[n % 10] + (n % 10 !== 0 ? " و " : "") + tens[Math.floor(n / 10)];
        if (n < 1000) return hundreds[Math.floor(n / 100)] + (n % 100 !== 0 ? " و " + process(n % 100) : "");
        if (n < 1000000) {
            let thous = Math.floor(n / 1000), rem = n % 1000, thWord = (thous === 1) ? "ألف" : (thous === 2) ? "ألفان" : (thous <= 10) ? process(thous) + " آلاف" : process(thous) + " ألف";
            return thWord + (rem !== 0 ? " و " : " " + process(rem));
        }
        return n.toString();
    }
    return process(num).trim();
}

function wrapText(text, maxLength = 32) {
    if (!text) return "";
    const words = text.split(" ");
    let lines = [];
    let currentLine = "";
    words.forEach(word => {
        if ((currentLine + word).length <= maxLength) {
            currentLine += (currentLine === "" ? "" : " ") + word;
        } else {
            lines.push(currentLine);
            currentLine = word
    lines.push(currentLine);
    return lines.join("\n");
}

function formatTableLine(col1, col2, col3) {
    let c1 = String(col1).trim();
    let c2 = String(col2).trim();
    let c3 = String(col3).trim();
    
    c1 = c1.padEnd(11, " ");
    c2 = c2.padEnd(10, " ");
    c3 = c3.padStart(11, " ");
    return `${c1}${c2}${c3}`;
}

function buildReceiptText() {
    const inv = JSON.parse(localStorage.getItem('invoiceSettings')) || { 
        title: 'بيان توريد', collectorLabel: 'المحصل', collectorName: 'الخليلي', phone: '01011111111',
        countLabel: 'العدد', categoryLabel: 'الفئة', totalLabel: 'الناتج', note: '',
        showExpenses: true, showDeficit: true, showDeferred: true, showSupply: true, showNet: true 
    };
    
    const now = new Date();
    const dateStr = now.toLocaleDateString('en-US'); 
    const timeStr = now.toLocaleTimeString('en-US', {hour: '2-digit', minute:'2-digit'});

    let txt = "\n\n";
    
    if (inv.title && inv.title.trim() !== "" && inv.title !== "0") {
        txt += `[TITLE]${inv.title}\n`;
    }
    
    if (inv.collectorName && inv.collectorName.trim() !== "" && inv.collectorName !== "0") {
        txt += `${inv.collectorLabel || 'المحصل'}: ${inv.collectorName}\n`;
    }
    
    if (inv.phone && inv.phone.trim() !== "" && inv.phone !== "0") {
        txt += `الهاتف: ${String(inv.phone).replace(/[\u0660-\u0669]/g, d => d.charCodeAt(0) - 1632)}\n`;
    }
    
    txt += "ـــــــــــــــــــــــــــــــــــــــــــــــــــــــ\n";
    txt += `التاريخ: ${dateStr} - ${timeStr}\n`;
    txt += "ــــــــــــــــــــــــــــــــــــــــــــــــــــــــ\n";
    
    const headTotal = inv.totalLabel || "العدد";
    const headCategory = inv.categoryLabel || "الفئة";
    const headCount = inv.countLabel || "الناتج";
    
    txt += formatTableLine(headTotal, headCategory, headCount) + "\n";
    txt += "ــــــــــــــــــــــــــــــــــــــــــــــــــــــــ\n";

    const cats = window.categories || [200, 100, 50, 20, 10, 5, 1];
    cats.forEach(c => {
        let el = document.getElementById("count_" + c);
        let n = el ? (parseFloat(el.value) || 0) : 0;
        if (n > 0) {
            let itemTotal = (n * c).toString();
            let itemCategory = c.toString();
            let itemCount = n.toString();
            txt += formatTableLine(itemTotal, itemCategory, itemCount) + "\n";
        }
    });
    
    txt += "ــــــــــــــــــــــــــــــــــــــــــــــــــــــــ\n";
    
    txt += `[TITLE]${(window.currentGrandTotal || 0).toString()}\n`;
    
    let extra = "";
    const parseNum = window.parseLocaleNumber || parseFloat;
    const expensesInput = document.getElementById('expenses');
    const deficitPaymentInput = document.getElementById('deficit-payment');
    const deferredInvoicesSelect = document.getElementById('deferred-invoices');
    const supplyInput = document.getElementById('supply');
    const netAmountValueElement = document.getElementById('net-amount-value');
    const netStatusElement = document.getElementById('net-status');

    const expVal = expensesInput ? parseNum(expensesInput.value) : 0;
    if(inv.showExpenses && expVal > 0) extra += `المصروفات: ${expVal.toString()}\n`;
    
    const defPayVal = deficitPaymentInput ? parseNum(deficitPaymentInput.value) : 0;
    if(inv.showDeficit && defPayVal > 0) extra += `سداد عجز: ${defPayVal.toString()}\n`;
    
    const defInvVal = deferredInvoicesSelect ? parseNum(deferredInvoicesSelect.value) : 0;
    if(inv.showDeferred && defInvVal > 0) extra += `فواتير مؤجلة: ${defInvVal.toString()}\n`;
    
    const supVal = supplyInput ? parseNum(supplyInput.value) : 0;
    if(inv.showSupply && supVal > 0) extra += `مبلغ التوريد: ${supVal.toString()}\n`;
    
    const netVal = netAmountValueElement ? parseNum(netAmountValueElement.textContent) : 0;
    if(inv.showNet && netVal > 0) {
        let englishNet = String(netAmountValueElement.textContent).replace(/,/g, '');
        extra += `الصافي (${netStatusElement ? netStatusElement.textContent : ''}): ${englishNet}\n`;
    }

    if(extra !== "") {
        txt += "ــــــــــــــــــــــــــــــــــــــــــــــــــــــــ\n";
        txt += extra;
    }

    txt += "ــــــــــــــــــــــــــــــــــــــــــــــــــــــــ\n";
    
    if(inv.note && inv.note.trim() !== "" && inv.note !== "0") {
        txt += `${wrapText(inv.note, 32)}\n`;
        txt += "ــــــــــــــــــــــــــــــــــــــــــــــــــــــــ\n";
    }
    
    return txt;
}

function printReceipt() {
    if (window.playSoundSafe) window.playSoundSafe("Print.mp3");
    const settings = JSON.parse(localStorage.getItem('appSettings')) || {};
    const mac = settings.printerMac;
    const printBtn = document.getElementById('print-btn');
    
    if (!mac) { 
        if (window.showNotification) window.showNotification("اختر الطابعة من الإعدادات", 'error'); 
        if (window.toggleSettingsModal) window.toggleSettingsModal(); 
        return; 
    }
    if (printBtn) {
        printBtn.disabled = true; 
        printBtn.textContent = "⏳ جاري الطباعة...";
    }
    try {
        const receiptText = buildReceiptText();
        if (window.AndroidBridge) { 
            window.AndroidBridge.printToDevice(mac, receiptText); 
        }
    } catch (e) { 
        if (window.showNotification) window.showNotification('خطأ: ' + e.message, 'error'); 
    } finally { 
        setTimeout(() => { 
            if (printBtn) {
                printBtn.disabled = false; 
                printBtn.textContent = "🖨️ طباعة"; 
            }
        }, 3000); 
    }
}

function loadPrinters() {
    const printerSelect = document.getElementById('printer-mac');
    if (!window.AndroidBridge) { 
        if (window.showNotification) window.showNotification('الجسر غير متصل', 'error'); 
        return; 
    }
    const data = window.AndroidBridge.getPairedDevices();
    if (data === "OFF") { 
        if (window.showNotification) window.showNotification('شغل البلوتوث', 'error'); 
        return; 
    }
    if (printerSelect) {
        printerSelect.innerHTML = '<option value="">-- اختر طابعة --</option>';
        data.split(',').forEach(d => {
            if (d.includes('|')) {
                const [name, mac] = d.split('|');
                const opt = document.createElement('option');
                opt.value = mac.trim(); 
                opt.textContent = name.trim();
                printerSelect.appendChild(opt);
            }
        });
    }
}

function buildPaymentWarningReceipt() {
    const warningNote = document.getElementById('warning-note');
    const warningPhone = document.getElementById('warning-phone');
    const note = warningNote ? warningNote.value.trim() : '';
    const phone = warningPhone ? warningPhone.value.trim() : '';
    
    let txt = "\n\n";
    let hasData = false;

    if (note !== "" && note !== "0") {
        txt += `${wrapText(note, 32)}\n`;
        hasData = true;
    }
    if (phone !== "" && phone !== "0") {
        txt += `${phone}\n`;
        hasData = true;
    }

    if (hasData) {
        txt += "ــــــــــــــــــــــــــــــــــــــــــــــــــــــــ\n";
        return txt;
    }
    return null;
}

function buildCollectorReceipt() {
    const collectorId = document.getElementById('collector-id');
    const vodafonePhone = document.getElementById('vodafone-phone');
    const instapayPhone = document.getElementById('instapay-phone');

    const name = collectorId ? collectorId.value.trim() : '';
    const vodafone = vodafonePhone ? vodafonePhone.value.trim() : '';
    const instapay = instapayPhone ? instapayPhone.value.trim() : '';

    let txt = "\n\n";
    txt += "[TITLE]بيانات التواصل مع المحصل\n\n";
    let hasData = false;

    if (name !== "" && name !== "0") {
        txt += `اسم المحصل:\n${name}\n\n`;
        hasData = true;
    }
    if (vodafone !== "" && vodafone !== "0") {
        txt += `فودافون كاش: رقم الهاتف\n${vodafone}\n\n`;
        hasData = true;
    }
    if (instapay !== "" && instapay !== "0") {
        txt += `انستاباي: رقم الهاتف\n${instapay}\n\n`;
        hasData = true;
    }

    if (hasData) {
        txt += "ــــــــــــــــــــــــــــــــــــــــــــــــــــــــ\n";
        return txt;
    }
    return null;
}

function printPaymentWarning() {
    const settings = JSON.parse(localStorage.getItem('appSettings')) || {};
    const mac = settings.printerMac;
    if (!mac) { 
        if (window.showNotification) window.showNotification("اختر الطابعة من الإعدادات", 'error'); 
        if (window.toggleSettingsModal) window.toggleSettingsModal(); 
        return; 
    }

    const receiptText = buildPaymentWarningReceipt();
    if (!receiptText) {
        if (window.showNotification) window.showNotification("لا توجد بيانات صالحة للطباعة", "error");
        return;
    }

    if (window.playSoundSafe) window.playSoundSafe("Print.mp3");
    try {
        if (window.AndroidBridge) { 
            window.AndroidBridge.printToDevice(mac, receiptText); 
            if (window.showNotification) window.showNotification("جاري طباعة الإخطار...");
        } else {
            console.log("AndroidBridge غائب، نص الفاتورة:\n", receiptText);
        }
    } catch (e) { 
        if (window.showNotification) window.showNotification('خطأ: ' + e.message, 'error'); 
    }
}

function printCollectorContact() {
    const settings = JSON.parse(localStorage.getItem('appSettings')) || {};
    const mac = settings.printerMac;
    if (!mac) { 
        if (window.showNotification) window.showNotification("اختر الطابعة من الإعدادات", 'error'); 
        if (window.toggleSettingsModal) window.toggleSettingsModal(); 
        return; 
    }

    const receiptText = buildCollectorReceipt();
    if (!receiptText) {
        if (window.showNotification) window.showNotification("لا توجد بيانات صالحة للطباعة", "error");
        return;
    }

    if (window.playSoundSafe) window.playSoundSafe("Print.mp3");
    try {
        if (window.AndroidBridge) { 
            window.AndroidBridge.printToDevice(mac, receiptText); 
            if (window.showNotification) window.showNotification("جاري طباعة بيانات التواصل...");
        } else {
            console.log("AndroidBridge غائب، نص الفاتورة:\n", receiptText);
        }
    } catch (e) { 
        if (window.showNotification) window.showNotification('خطأ: ' + e.message, 'error'); 
    }
}

window.tafqeet = tafqeet;
window.wrapText = wrapText;
window.formatTableLine = formatTableLine;
window.buildReceiptText = buildReceiptText;
window.printReceipt = printReceipt;
window.loadPrinters = loadPrinters;
window.buildPaymentWarningReceipt = buildPaymentWarningReceipt;
window.buildCollectorReceipt = buildCollectorReceipt;
window.printPaymentWarning = printPaymentWarning;
window.printCollectorContact = printCollectorContact;
