function showNotification(message, type = 'success') {
    const NOTIFICATION_BOX = document.getElementById('notification-box');
    if (type === 'error' && window.playSoundSafe) window.playSoundSafe("Error.mp3");
    if (NOTIFICATION_BOX) {
        NOTIFICATION_BOX.textContent = message;
        NOTIFICATION_BOX.className = type + ' show';
        NOTIFICATION_BOX.style.visibility = 'visible';
        setTimeout(() => { NOTIFICATION_BOX.classList.remove('show'); }, 3000);
    }
}

function showRandomDhikr() {
    const localAzkar = JSON.parse(localStorage.getItem('local_azkar')) || ["أستغفر الله العظيم", "سبحان الله وبحمده", "لا حول ولا قوة إلا بالله"];
    const lastDhikr = localStorage.getItem('last_dhikr_shown');
    
    let filtered = localAzkar.filter(a => a !== lastDhikr);
    if (filtered.length === 0) filtered = localAzkar;
    
    const pick = filtered[Math.floor(Math.random() * filtered.length)];
    
    const dhikrContent = document.getElementById('dhikr-content');
    const dhikrToast = document.getElementById('dhikr-toast');
    if (dhikrContent && dhikrToast) {
        dhikrContent.textContent = pick;
        dhikrToast.classList.add('show');
        localStorage.setItem('last_dhikr_shown', pick);
        
        if (window.playSoundSafe) window.playSoundSafe("Save.mp3");
        setTimeout(closeDhikr, 10000);
    }
}

function closeDhikr() { 
    const dhikrToast = document.getElementById('dhikr-toast');
    if (dhikrToast) dhikrToast.classList.remove('show'); 
}

function closePopup(id) { 
    const popup = document.getElementById(id);
    if (popup) popup.style.display = 'none'; 
}

setTimeout(showRandomDhikr, 3000); 
setInterval(showRandomDhikr, 15 * 60 * 1000);

window.showNotification = showNotification;
window.showRandomDhikr = showRandomDhikr;
window.closeDhikr = closeDhikr;
window.closePopup = closePopup;
